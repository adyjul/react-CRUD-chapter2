const SearchInput = () => {
    return(
        <section className="search-bar">
            <input type="text" placeholder="Cari berdasarkan judul ..." />                  
        </section>
    )
}

export default SearchInput