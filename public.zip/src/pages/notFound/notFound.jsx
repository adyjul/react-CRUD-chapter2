const NotFound = ()=> {
    return(
        <main><section><h2>404</h2><p>Page not found</p></section></main>
    )
}

export default NotFound;