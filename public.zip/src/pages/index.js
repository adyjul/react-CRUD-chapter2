import Home from "./home/home";
import TambahData from "./tambah/tambah";
import Arsip from "./arsip/arsip";
import Detail from "./detail/detail";

export { Home, TambahData, Arsip, Detail }